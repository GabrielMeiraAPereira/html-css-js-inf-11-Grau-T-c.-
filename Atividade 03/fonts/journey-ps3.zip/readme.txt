  ___________________________________________
 /                                           \
<  --- JourneyPS3 Font by Hauke Petersen ---  >
 \___________________________________________/


Info:
-----

This font is based on the title card of the Video Game "Journey"
by thatgamecompany for PlayStation 3. The 7 letters within the
game's name use and original design and are not part of complete
font set. Since it looks so nice, I decided to create a full-
fledged font by creating the remaining characters based on the
official design.


Creation:
---------

I used a vector image file from an official press kit released by
thatgamecompany. Using vector graphics editing software I created
the remaining letters, numerics and parenthesis based on the
official characters. I have created only the most common characters
you'd find on a standard US keyboard.
In the next Step I exported the characters into single files and
imported them into a very old yet neat font creation software
called "Manutius". After rezising the characters and setting the
correct spacings the font was saved as PostScript font format.


Legal Stuff:
------------

The official Journey logo is (C) 2012, Sony Entertainment. I do
not own the rights to the design of the original Journey letters.
This is only a fan-made non-profit attempt to create a full font
based on the original design.


Enjoy the font! :-)
-Hauke